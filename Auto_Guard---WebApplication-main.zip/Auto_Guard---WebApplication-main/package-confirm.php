<!DOCTYPE html>
<html>
<head>
	<title>Package Confirm</title>

	<style type="text/css">
		
		.con-msg{
			text-align: center;
			font-size: 35px;
			color: black;
			padding: 10px 0;
			margin-bottom: 500px;		
		}

	</style>

	<link rel="stylesheet" type="text/css" href="styles/ss.css">
	

</head>

<body>


	<?php include 'navigation.php'; ?>

	<br>


	<p class="con-msg"> You have successfully Selected Package in our company. <br>
	 Please go to account view your details. </p>


	<?php include 'footer.php'; ?>
	

</body>
</html>