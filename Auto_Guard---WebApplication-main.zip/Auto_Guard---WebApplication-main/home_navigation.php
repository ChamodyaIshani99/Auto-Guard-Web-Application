<!DOCTYPE html>
<html>
<head>
	<title>Home Navigation bar</title>

	<link rel="stylesheet" type="text/css" href="styles/ss.css">

	

</head>

<body>

	<ul class="navi">
		<li class="navi2"><a class="naviA" href="home.php"> Home</a></li>
		<li class="navi2"><a class="naviA" href="contactPage.php">Contact</a></li>
		<li class="navi2"><a class="naviA" href="#">About Us</a>
			<ul class="dropdown navi">
				<li class="navi2"> <a class="naviA" href="about_company.php">Company About </a></li>
				<li class="navi2"> <a class="naviA" href="about_director.php">Director board about </a></li>
			</ul>
		</li>
		<li class="navi1"><a class="naviA" href="login_account.php">Login</a></li>
		<li class="navi1"><a class="naviA" href="signUp_account.php">SignUp</a></li>
	</ul>
</body>
</html>
