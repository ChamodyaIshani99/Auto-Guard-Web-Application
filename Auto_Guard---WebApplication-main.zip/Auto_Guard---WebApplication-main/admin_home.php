<!DOCTYPE html>
<html>
<head>
	<title>Admin Home</title>

	<link rel="stylesheet" type="text/css" href="styles/ss.css">
	<link rel="stylesheet" type="text/css" href="styles/account.css">

</head>
<body>

	<ul class="navi">
		<li class="navi2"><a class="naviA" href="admin_home.php"> Admin Home</a></li>
		<li class="navi1"><a class="naviA" href="#">(0)</a></li>
		<li class="navi1"><a class="naviA" href="Home.php">LogOut</a></li>
	</ul>

	<div class="abc">
		<div class="a"> 
			<div class="main--content">
				<div class="header--wrapper">
					<div class="header--title">
						<h2>Admin Account</h2>
						
					</div>
				
				</div>
			
			</div>

			<div class="main--content">
				<h3>Admin facilities </h3>
				<div class="details_a">
					<div class="acc_details" style="height: 240px; width: 240px;">
						
						<h2> Add Vehicle estimate value </h2>
						<a class="a_btn" href="admin_estimate.php"> Click here </a>

					</div>

					<div class="acc_details" style="height: 240px; width: 240px;">
						
						<h2> Make Accident Report </h2><br>
						<a class="a_btn" href="admin_accident_report.php"> Click here </a>

					</div>

					<div class="acc_details" style="height: 240px; width: 240px;">
						
						<h2> Genarate Claim Details </h2>
						<a class="a_btn" href="admin_claim.php"> Click here </a>

					</div>

					<div class="acc_details" style="height: 240px; width: 240px;">
						
						<h2> View Coustomer Support Tickets </h2>
						<a class="a_btn" href="admin_ticket.php"> Click here </a>

					</div>


					</div>


				
				</div>
			
			</div>
			

		</div>
	
	

</body>
</html>