<!DOCTYPE html>
<html>
<head>
	<title>Account Navigation</title>

	<link rel="stylesheet" type="text/css" href="styles/ss.css">
	<link rel="stylesheet" type="text/css" href="styles/account.css">

</head>

<body>

	<ul class="navi">
		<li class="navi2"><a class="naviA" href="logout.php"> LogOut</a></li>
		<li class="navi2"><a class="naviA" href="contactPage.php">Contact</a></li>
		<li class="navi2"><a class="naviA" href="#">About Us</a>
			<ul class="dropdown navi">
				<li class="navi2"> <a class="naviA" href="about_company.php">Company About </a></li>
				<li class="navi2"> <a class="naviA" href="about_director.php">Director board about </a></li>
			</ul>
		</li>
		<li class="navi1"><a class="naviA" href="#">(0)</a></li>
		<li class="navi1"><a class="naviA" href="account.php">Account</a></li>
	</ul>

</body>
</html>

