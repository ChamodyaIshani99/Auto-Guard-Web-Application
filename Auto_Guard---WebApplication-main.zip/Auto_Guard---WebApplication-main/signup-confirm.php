<!DOCTYPE html>
<html>
<head>
	<title>Signup confirm</title>

	<style type="text/css">
		
		.con-msg{
			text-align: center;
			font-size: 35px;
			color: black;
			padding: 10px 0;
			margin-bottom: 500px;		
		}

	</style>

	<link rel="stylesheet" type="text/css" href="styles/ss.css">
	

</head>

<body>

	<?php

		include ('home_navigation.php');

	?>

	<br>


	<p class="con-msg"> You have successfully created an account in our company. <br>
	 Please login again to access that account. </p>


	 <?php include 'footer.php'; ?>

</body>
</html>